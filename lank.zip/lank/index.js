var express=require("express");
var bodyParser=require('body-parser');
var app = express();

var registerController=require('./register-controller');
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());
/* route to handle login and registration */
app.post('/api/register',registerController.register);

app.listen(3000);