<?php
session_start();

require_once 'config.php';
//starting pagination for items

$em = $_SESSION["email"];

$sqlindex="SELECT * FROM orderstable where useremail = '$em'";

$resultindex = mysqli_query($con, $sqlindex);

echo "".$em;
$ordersArray = array();
$buyerArray = array();
                while ($product = mysqli_fetch_array($resultindex)) {
                            
                            array_push($ordersArray,$product['orders']);
                            array_push($buyerArray,$product['useremail']);
                            
                }
echo "orderArray".count($ordersArray);
                  $details =  array();
             for($x=0;$x<count($ordersArray);$x++)
             echo $x."=>". $ordersArray[$x]."<br><br><br>";
             
             for($x=0;$x<count($ordersArray);$x++)
             {
                 
                 if (strpos($ordersArray[$x], $em) !== false){
                     array_push($details, $ordersArray[$x]);
                }
             }
             for($x=0;$x<count($details);$x++)
             {
             echo $x."Buyers =>". $details[$x]."<br><br><br>";
                 
             }
             
             echo "Buyers orders......=>"."<br><br><br>";
             for($x=0;$x<count($details);$x++)
             {
             echo $x."Bus =>". $buyerArray[$x]."order: ".$details[$x]."<br><br><br>";
                 
             }
?>