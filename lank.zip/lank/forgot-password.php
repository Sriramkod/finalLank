<?php require_once "controllerUserData.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lank's Shopping</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="buyerseller.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link href='https://css.gg/profile.css' rel='stylesheet'>

<style>
    .header {
  padding: 2px;
  text-align: center;
  background: #1bac2c;
  color: white;
  font-size: 5px;
}
</style>
</head>
<body>
     <div class="header">
      

        <h1><center> <h1>Lank's Shopping</h1> </center></h1>
        <p style="font-size:20px;">shop your favorite items here</p>
  
    </div>
  
    <div class="container">
        <br><br><br><br>
            <div class="col-md-4 offset-md-4 form login-form">
               <div class="row">
         
        <div class="column">  
      &nbsp;&nbsp;&nbsp;&nbsp;<a href="sellerlogin.php" style="text-decoration:none;">&nbsp;&nbsp;<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
         <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
        </svg><br><p style="font-size:15px;">&nbsp;&nbsp;Seller Login</p>
    </a>
    </div>
    <div class="column">&nbsp;&nbsp;&nbsp;</div>
    <div class="column">&nbsp;&nbsp;&nbsp;</div>
    <div class="column">&nbsp;&nbsp;&nbsp;</div>
          <div class="column">
<a href="home.php" style="text-decoration:none;">&nbsp;&nbsp;<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-house-door" viewBox="0 0 16 16">
  <path d="M8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4.5a.5.5 0 0 0 .5-.5v-4h2v4a.5.5 0 0 0 .5.5H14a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.354 1.146zM2.5 14V7.707l5.5-5.5 5.5 5.5V14H10v-4a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v4H2.5z"/>
</svg><br><p style="font-size:15px;">&nbsp;&nbsp;&nbsp;Home</p></a>

</div>
 <div class="column">&nbsp;&nbsp;&nbsp;</div>
    <div class="column">&nbsp;&nbsp;&nbsp;</div>
    <div class="column">&nbsp;&nbsp;&nbsp;</div>
         <div class="column">  
      &nbsp;&nbsp;&nbsp;&nbsp;<a href="login.php" style="text-decoration:none;">&nbsp;&nbsp;<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
         <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
        </svg><br><p style="font-size:15px;">&nbsp;&nbsp;&nbsp;Buyer Login</p>
    </a>
    </div>
</div>
				<div class="form-box">
                <form action="forgot-password.php" method="POST" autocomplete="">
                    <h2 class="text-center">Forgot Password</h2>
                    <p class="text-center">Enter your email address</p>
                    <?php
                        if(count($errors) > 0){
                            ?>
                            <div class="alert alert-danger text-center">
                                <?php 
                                    foreach($errors as $error){
                                        echo $error;
                                    }
                                ?>
                            </div>
                            <?php
                        }
                    ?>
                    <div class="form-group">
                        <input class="form-control" type="email" name="email" placeholder="Enter email address" required value="<?php echo $email ?>">
                    </div>
                    <div class="form-group">
                        <input class="form-control button" type="submit" name="check-email" value="Continue">
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</body>
</html>