<?php
  
$db_name = "lank";  
 $mysql_user = "root";  
 $mysql_pass = "";  
 $server_name = "localhost";   
 $db = mysqli_connect($server_name,$mysql_user,$mysql_pass,$db_name);
   
// Check connection  
if ($db->connect_error) {  
    die("Connection failed: " . $db->connect_error);  
}
?>