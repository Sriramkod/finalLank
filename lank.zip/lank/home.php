<?php
$db_name = "lank";  
 $mysql_user = "root";  
 $mysql_pass = "";  
 $server_name = "localhost";
 $connect = mysqli_connect($server_name,$mysql_user,$mysql_pass,$db_name);
function make_query($connect)
{
 $query = "SELECT * FROM imagestable ORDER BY RAND()
LIMIT 5";
 $result = mysqli_query($connect, $query);
 return $result;
}

function make_slide_indicators($connect)
{
 $output = ''; 
 $count = 0;
 $result = make_query($connect);
 while($row = mysqli_fetch_array($result))
 {
  if($count == 0)
  {
   $output .= '
   <li data-target="#dynamic_slide_show" data-slide-to="'.$count.'" class="active"></li>
   ';
  }
  else
  {
   $output .= '
   <li data-target="#dynamic_slide_show" data-slide-to="'.$count.'"></li>
   ';
  }
  $count = $count + 1;
 }
 return $output;
}

function make_slides($connect)
{
 $output = '';
 $count = 0;
 $result = make_query($connect);
 while($row = mysqli_fetch_array($result))
 {
  if($count == 0)
  {
   $output .= '<div class="item active">';
  }
  else
  {
   $output .= '<div class="item">';
  }
  $output .= '
  <center> <div class="caption"><h3>
 <div class="zoom"><img src="images/'.$row['imagename'].'" width="" height="450"/></div>
  </h3></div>
  </center>
  </div>
  ';
  $count = $count + 1;
 }
 return $output;
}

?>
<!DOCTYPE html>
<html>
 
 <head>
     <meta charset="UTF-8">
	
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet">
	
  <title>Lank's shoppping</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;700&display=swap" rel="stylesheet" />

  <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon" />


  <!-- Carousel -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/css/glide.core.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/css/glide.theme.min.css
">
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

  <!-- Custom StyleSheet -->
  <link rel="stylesheet" href="indexstyles.css" />

  <style>
 #id1 {
  height: 100%;
  width: 100%;
  
}
.zoom {
  
  transition: transform .2s; /* Animation */
  
  margin: 0 auto;
}

.zoom:hover {
  transform: scale(1.5); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}
.navbar-light .navbar-brand {
	color: #000;
	font-size: 25px;
	text-transform: uppercase;
	font-weight: bold;
	letter-spacing: 2px;
}
.navbar-light .navbar-nav .active>.nav-link, .navbar-light .navbar-nav .nav-link.active, .navbar-light .navbar-nav .nav-link.show, .navbar-light .navbar-nav .show>.nav-link {
	color: #000;
}
.navbar-light .navbar-nav .nav-link {
	color: #000;
}
.navbar-toggler {
	background: #0000FF;
}
.navbar-nav {
	text-align: center;
}
.nav-link {
	padding: .2rem 1rem;
}
.nav-link.active, .nav-link:focus {
	color: #000;
}
.navbar-toggler {
	padding: 1px 5px;
	font-size: 18px;
	line-height: 0.3;
}
.navbar-light .navbar-nav .nav-link:focus, .navbar-light .navbar-nav .nav-link:hover {
	color: #000;
}
  </style>
 </head>
 <body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
		<div class="container" style="color:white; background-color:#1bac2c;">
			<a class="navbar-brand" href="#" style="color:white;">
			<div>
Lank's Shopping</a><br><b><p>Shop your favorite items here</p></b></div> <button aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler" data-target="#navbarSupportedContent" data-toggle="collapse" type="button"><span class="navbar-toggler-icon"></span></button>
			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item active">
						<a class="nav-link" href="#" style="color:white;"><b>Home</b></a>
					</li>
					
					<li class="nav-item">
						<a class="nav-link" href="#categories" style="color:white;"><b>Categories</b></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="login.php" style="color:white;"><b>Login</b></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="sellerlogin.php" style="color:white;"><b>Seller</b></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="login.php" style="color:white;"><b>Buyer</b></a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js">
	</script> 
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js">
	</script> 
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js">
	</script>
  <div class="container">
   <h2 align="center"></h2>
   <br />
   <div id="dynamic_slide_show" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
    <?php echo make_slide_indicators($connect); ?>
    </ol>

    <div id="id1" class="carousel-inner">
     <?php echo make_slides($connect); ?>
    </div>
    <a class="left carousel-control" href="#dynamic_slide_show" data-slide="prev">
     <span class="glyphicon glyphicon-chevron-left"></span>
     <span class="sr-only">Previous</span>
    </a>

    <a class="right carousel-control" href="#dynamic_slide_show" data-slide="next">
     <span class="glyphicon glyphicon-chevron-right"></span>
     <span class="sr-only">Next</span>
    </a>

   </div>
   <br><br><br><br>
   <hr>
    <div class="title__container">
          <div class="section__titles">
            
            <div class="section__title active">
             
             <center> <h3 class="primary__title" id="categories" style="color:white; background-color:green;">Categories</h3> </center>
            </div>
          </div>
        </div>
        
        <hr>
        
        <div class="row">
  <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>
      <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>
  <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>
      <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>
  <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>
      <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>

    <div class="column"><div class="zoom"><a  href="book.php"><img src="./projectimages/project-book.png" width="150"></a>
    </div></div>
     <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>
      <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>

    <div class="column"><div class="zoom"><a  href="dress.php"><img src="./projectimages/project-dress.png" width="150"></a>
    </div></div>
     <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>
      <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>
       <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>

        <div class="column"><div class="zoom"><a  href="elec.php"><img src="./projectimages/project-electronic.png" width="150"></a>
    </div></div>
     <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>
      <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>
       <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>
        <div class="column"><div class="zoom"><a  href="bagf.php?"><img src="./projectimages/project-bag.png" width="150"></a>
    </div></div>
     <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>
      <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>
       <div class="column">&nbsp;&nbsp;&nbsp;</div> <div class="column">&nbsp;&nbsp;&nbsp;</div>

    <div class="column"><div class="zoom"><a  href="sport.php"><img src="./projectimages/project-sport.png" width="150"></a>
    </div></div>
    </div>
    
    <br><br><br><br>

    <!-- Hero -->
    <div>
      <div class="glide" id="glide_1">
        <div class="glide__track" data-glide-el="track">
              <div class="hero__center">
                <div class="hero__left">
                  <span style="color:black; font-size:20px;">LANK'S SHOPPING</span>
                  <h1 style="color:blue; font-size:25px;">Knowledge is wealth, buy our book and learn and earn more.</h1>
                  
                  <a href="book.php"><button class="hero__btn">SHOP NOW</button></a>
                </div>
                <div class="hero__right">
                  <div class="hero__img-container">
                    <img class="banner_01" src="./projectimages/project-book.png" alt="banner2" />
                  </div>
                </div>
              </div>
	<br><br><br><br>
              <div class="hero__center">
                <div class="hero__left">
                  <span style="color:black; font-size:20px;">LANK'S SHOPPING</span>
                  <h1 style="color:blue; font-size:25px;">Premium Quality dresses available here...</h1>
                  <a href="dress.php"><button class="hero__btn">SHOP NOW</button></a>
                </div>
                <div class="hero__right">
                  <img class="banner_02" src="./projectimages/project-dress.png" alt="banner2" />
                </div>
              </div>
              
              <div class="hero__center">
                <div class="hero__left">
                  <span style="color:black; font-size:25px;">LANK'S SHOPPING</span>
                  <h1 style="color:blue; font-size:25px;">Brand new electronic gadgets</h1>
                  <p></p>
                  <a href="elec.php"><button class="hero__btn">SHOP NOW</button></a>
                </div>
                <div class="hero__right">
                  <img class="banner_02" src="./projectimages/project-electronic.png" alt="banner2" />
                </div>
              </div>
              
              <div class="hero__center">
                <div class="hero__left">
                  <span style="color:black; font-size:25px;">LANK'S SHOPPING</span>
                  <h1 style="color:blue; font-size:25px;">Shop Footwear and bags on lank's get excited...</h1>
                  <p></p>
                  <a href="bagf.php"><button class="hero__btn">SHOP NOW</button></a>
                </div>
                <div class="hero__right">
                  <img class="banner_02" src="./projectimages/project-bag.png" alt="banner2" />
                </div>
              </div>
              
              <div class="hero__center">
                <div class="hero__left">
                  <span style="color:black; font-size:25px;">LANK'S SHOPPING</span>
                  <h1 style="color:blue; font-size:25px;">All kinds of sports wear are available...</h1>
                  <p></p>
                  <a href="sport.php"><button class="hero__btn">SHOP NOW</button></a>
                </div>
                <div class="hero__right">
                  <img class="banner_02" src="./projectimages/project-sport.png" alt="banner2" />
                </div>
              </div>
              
              
              
          
        </div>


    <br><br><br><br>
  </div>
 </body>
</html>