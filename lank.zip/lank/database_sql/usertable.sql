-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 12, 2022 at 06:00 AM
-- Server version: 10.5.12-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lank`
--

-- --------------------------------------------------------

--
-- Table structure for table `usertable`
--

CREATE TABLE `usertable` (
  `id` int(200) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code` mediumint(50) NOT NULL,
  `status` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `usertable`
--

INSERT INTO `usertable` (`id`, `name`, `email`, `password`, `code`, `status`) VALUES
(36, 'sriram', 'kodipakasriram@gmail.com', '$2y$10$yiCZ33VP2l6ilDvsYfPH6e6rfb4E9JMitBH0Pn.77R7btsWa8UDD6', 689727, 'verified'),
(37, 'March', 'kodipaka123@gmail.com', '$2y$10$2IOt6lO1lyttTsb8KIEaUelvmwvfg6fF5lAagbLkOgPxm99WsCdVi', 0, 'notverified'),
(38, 'deeku', 'akbk4332@gmail.com', '$2y$10$UMbBoti8WPRS3f9G3w9gPOugcCML5NWRizQAf2fL97B5qWwALLldO', 138565, 'notverified'),
(39, 'sriram', 'kod#12@gmail.com', '$2y$10$XdS/qa0F/3KesCAoJtSDOeXTvoQt1cNHIj9483eXZF65Hji.HpTNm', 788812, 'notverified'),
(40, 'sriram', 'kodipakasriram123@gmail.com', '$2y$10$xs8jiUdr/MJWXQjOf3mijOZIbRYaUGllWs2UsIyVpR2jCJPq0jLkS', 804619, 'notverified'),
(41, 'Ramk@gmail.com', 'Ramk@gmail.com', '$2y$10$6BrT6OsFlDCyAxqq0jnizeA3hmtaJLlyvj7GR9dD9zWoacTdB2tnu', 515077, 'notverified');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `usertable`
--
ALTER TABLE `usertable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `usertable`
--
ALTER TABLE `usertable`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
