-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 12, 2022 at 06:00 AM
-- Server version: 10.5.12-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lank`
--

-- --------------------------------------------------------

--
-- Table structure for table `imagestable`
--

CREATE TABLE `imagestable` (
  `id` int(255) NOT NULL,
  `imagename` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `selleremail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `category` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `imagestable`
--

INSERT INTO `imagestable` (`id`, `imagename`, `name`, `price`, `code`, `selleremail`, `category`) VALUES
(33, 'bag3.jpg', 'Inception', '1050', '328492', 'kodipakasriram@gmail.com', 'Bags & Footwear'),
(34, 'bag4.jpg', 'Batman Begins', '120', '721576', 'kodipakasriram@gmail.com', 'Books'),
(35, 'bag8.jpg', 'Jurasic Park', '120', '803766', 'kodipaka123@gmail.com', 'Bags & Footwear'),
(36, 'bag5.jpg', 'Bag Bat', '130', '711637', 'kodipaka123@gmail.com', 'Bags-Footwear'),
(37, 'sim1.jpeg', 'dress fasion', '25', '430231', 'kodipaka123@gmail.com', 'Dress'),
(38, 'sim3.jpeg', 'dress3', '125', '418446', 'kodipaka123@gmail.com', 'Dress'),
(39, 'project-sport.png', 'Inception', '145', '829530', 'kodipakasriram@gmail.com', 'Sports-Fitness'),
(40, 'project-electronic.png', 'Electric v', '247', '323379', 'kodipakasriram@gmail.com', 'Electronics');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `imagestable`
--
ALTER TABLE `imagestable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `imagestable`
--
ALTER TABLE `imagestable`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
