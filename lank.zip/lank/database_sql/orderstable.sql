-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Apr 12, 2022 at 06:01 AM
-- Server version: 10.5.12-MariaDB
-- PHP Version: 7.3.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lank`
--

-- --------------------------------------------------------

--
-- Table structure for table `orderstable`
--

CREATE TABLE `orderstable` (
  `id` int(255) NOT NULL,
  `useremail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `orders` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `totalprice` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `orderstable`
--

INSERT INTO `orderstable` (`id`, `useremail`, `orders`, `totalprice`, `date`) VALUES
(65, 'kodipakasriram@gmail.com', 'SellerEmail:kodipakasriram@gmail.com,Category:Sports-Fitness,Name:Inception,Quantity:1,price of individual item: 145,quantity_total_price: 145', '390', '2022-04-12'),
(66, 'kodipakasriram@gmail.com', 'SellerEmail:kodipaka123@gmail.com,Category:Dress,Name:dress3,Quantity:1,price of individual item: 125,quantity_total_price: 125', '390', '2022-04-12'),
(67, 'kodipakasriram@gmail.com', 'SellerEmail:kodipakasriram@gmail.com,Category:Books,Name:Batman Begins,Quantity:1,price of individual item: 120,quantity_total_price: 120', '390', '2022-04-12'),
(68, 'kodipakasriram@gmail.com', 'SellerEmail:kodipakasriram@gmail.com,Category:Electronics,Name:Electric v,Quantity:2,price of individual item: 247,quantity_total_price: 494', '624', '2022-04-12'),
(69, 'kodipakasriram@gmail.com', 'SellerEmail:kodipaka123@gmail.com,Category:Bags-Footwear,Name:Bag Bat,Quantity:1,price of individual item: 130,quantity_total_price: 130', '624', '2022-04-12'),
(70, 'Ramk@gmail.com', 'SellerEmail:kodipaka123@gmail.com,Category:Dress,Name:dress3,Quantity:1,price of individual item: 125,quantity_total_price: 125', '850', '2022-04-12'),
(71, 'Ramk@gmail.com', 'SellerEmail:kodipakasriram@gmail.com,Category:Sports-Fitness,Name:Inception,Quantity:5,price of individual item: 145,quantity_total_price: 725', '850', '2022-04-12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orderstable`
--
ALTER TABLE `orderstable`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orderstable`
--
ALTER TABLE `orderstable`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
