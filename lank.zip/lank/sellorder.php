<?php
session_start();

require_once 'config.php';
//starting pagination for items

$em = $_SESSION["email"];

$sqlindex="SELECT * FROM orderstable";

$resultindex = mysqli_query($con, $sqlindex);

$ordersArray = array();
$buyerArray = array();$dateArray = array();
                while ($product = mysqli_fetch_array($resultindex)) {
                            
                            array_push($ordersArray,$product['orders']);
                            array_push($buyerArray,$product['useremail']);
                            array_push($dateArray,$product['date']);
                            
                }

                  $details =  array();
            /* for($x=0;$x<count($ordersArray);$x++)
             echo $x."=>". $ordersArray[$x]."<br><br><br>";
             */
$newdateArray = array();$newbuyerArray=array();
             for($x=0;$x<count($ordersArray);$x++)
             {
                 
                 if (strpos($ordersArray[$x], $em) !== false){
                     array_push($details, $ordersArray[$x]);
	  array_push( $newdateArray, $dateArray[$x]);
	  array_push($newbuyerArray, $buyerArray[$x]);
                }
             }
            /*
             for($x=0;$x<count($details);$x++)
             {
             echo $x."Buyers =>". $details[$x]."<br><br><br>";
                 
             }
             */
            
          /*   for($x=0;$x<count($details);$x++)
             {
             echo $x."Buyer =>". $newbuyerArray[$x]."order: ".$details[$x]."Date:".$newdateArray[$x]."<br><br><br>";
                 
             }*/
?>
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>User Orders</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
           <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
           <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />  
      </head>  
      <body>  
           <br /><br />  
           <div class="container">  
           <div align="right">
    
    <a href="insertimg.php" type="button" name="add" id="add" class="btn btn-success">Add new Items</a>
   </div> 
                <h3 align="center">Lank's Shopping</h3>  
                <br />  
                <div class="table-responsive">  
                     <table id="employee_data" class="table table-striped table-bordered">  
                          <thead>  
                               <tr>  
                                    <td>Buyer Name</td>  
                                    <td>Orders</td> 
                                    <td>Order Date</td>  
                                    
                               </tr>  
                          </thead>  
                          <?php  
                          for($x=0;$x<count($details);$x++) 
                          {  
                               echo '  
                               <tr>  
                                    <td>'.$newbuyerArray[$x].'</td>  
                                    <td>'.$details[$x].'</td>  
                                    <td>'.$newdateArray[$x].'</td>  
                                      
                               </tr>  
                               ';  
                          }  
                          ?>  
                     </table>  
                </div>  
           </div>  
      </body>  
 </html>  
 <script>  
 $(document).ready(function(){  
      $('#employee_data').DataTable();  
 });  
 </script>