<?php
session_start();
$sizeofc="";
require_once 'config.php';
//starting pagination for items

// define how many results you want per page
$results_per_page = 4;

// find out the number of results stored in database

    $sqlindex="SELECT * FROM imagestable where category = 'Dress'";

$resultindex = mysqli_query($con, $sqlindex);
$number_of_results = mysqli_num_rows($resultindex);

// determine number of total pages available
$number_of_pages = ceil($number_of_results/$results_per_page);

// determine which page number visitor is currently on
if (!isset($_GET['page'])) {
  $page = 1;
} else {
  $page = $_GET['page'];
}

// determine the sql LIMIT starting number for the results on the displaying page
$this_page_first_result = ($page-1)*$results_per_page;

// retrieve selected results from database and display them on page
$sqlindex='SELECT * FROM imagestable where category = "Dress"  LIMIT ' . $this_page_first_result . ',' .  $results_per_page;
$resultindex = mysqli_query($con, $sqlindex);


//ending pagination for items


//echo "".$_SESSION['email'];
$userem = $_SESSION['email'];

if($_SESSION['email']==null)
{
    echo"<script>alert('Please login to proceed...');window.location.href='login.php';</script>";
    header('location:login.php');
    exit();
}

  $finn="";
            $fb2="";
            $namesofitems = array();
            $interm= array();$sepp=":";
            $tot=0;
// add, remove, empty
if (!empty($_GET['action'])) {
    switch ($_GET['action']) {
        // add product to cart
        case 'add':
            if (!empty($_POST['quantity'])) {
                $pid = $_GET['pid'];
                $query = "SELECT * FROM imagestable WHERE category = 'Dress' and id=" . $pid;
                $result = mysqli_query($con, $query);
                while ($product = mysqli_fetch_array($result)) {
                    $itemArray = [
                        $product['code'] => [
                            'name' => $product['name'],
                            'code' => $product['code'],
                            'quantity' => $_POST['quantity'],
                            'price' => $product['price'],
                            'imagename' => $product['imagename'],
                            'selleremail' => $product['selleremail'],
                            'category' => $product['category']
                        ]
                    ];
                    
                    if (isset($_SESSION['cart_item']) &&!empty($_SESSION['cart_item'])) {
                        if (in_array($product['code'], array_keys($_SESSION['cart_item']))) {
                            foreach ($_SESSION['cart_item'] as $key => $value) {
                                if ($product['code'] == $key) {
                                    if (empty($_SESSION['cart_item'][$key]["quantity"])) {
                                        $_SESSION['cart_item'][$key]['quantity'] = 0;
                                    }
                                    $_SESSION['cart_item'][$key]['quantity'] += $_POST['quantity'];
                                }
                                
                            }
                        } else {
                            $_SESSION['cart_item'] += $itemArray;
                        }
                    } else {
                        $_SESSION['cart_item'] = $itemArray;
                    }
                }
                echo "<script>
alert('Item added to cart...');

</script>";
?>

<?php
}
            break;
        case 'remove':
            if (!empty($_SESSION['cart_item'])) {
                foreach ($_SESSION['cart_item'] as $key => $value) {
                    if ($_GET['code'] == $key) {
                        unset($_SESSION['cart_item'][$key]);
                    }
                    if (empty($_SESSION['cart_item'])) {
                        unset($_SESSION['cart_item']);
                    }
                }
                
            }
            break;
        case 'empty':
            unset($_SESSION['cart_item']);
            
            break;
        case 'checkout':
             //session_start();
        ?>        <div class="row">
        <?php
            $total_quantity = 0;
            $total_price = 0;
            $finn="";
            $namesofitems = array();
            $interm= array();$sepp=":"
        ?>
        <table class="table">
            <tbody>
            <tr>
                <th class="text-left">Name</th>
                <th class="text-left">Code</th>
                <th class="text-right">Quantity</th>
                <th class="text-right">Item Price</th>
                <th class="text-right">Price</th>
                <th class="text-center">Remove</th>
            </tr>

            <?php
            if (isset($_SESSION['cart_item']) && !empty($_SESSION['cart_item'])){
                foreach ($_SESSION['cart_item'] as $item) {
                    $item_price = $item['quantity'] * $item['price'];
                    /*start*/
                    array_push($interm,"SellerEmail:".$item['selleremail'],"Category:".$item['category'],"Name:".$item['name'],"Quantity:".$item['quantity'],"price of individual item: ".$item['price'],"quantity_total_price: ".$item_price,"||");
                    array_push($namesofitems,$item['name'])
                    /*end*/
                    ?>
                    <tr>
                        <td class="text-left">
                            <img src="images/<?= $item['imagename']; ?>" alt="<?= $item['name'] ?>" class="img-fluid" width="100">
                            <?= $item['name'] ?>
                        </td>
                        <td class="text-left"><?= $item['name'] ?></td>
                        <td class="text-right"><?= $item['quantity'] ?></td>
                        <td class="text-right">$<?= number_format($item['price'], 2) ?></td>
                        <td class="text-right">$<?= number_format($item_price, 2) ?></td>
                        <td class="text-center">
                            <a href="dress.php?action=remove&code=<?= $item['code']; ?>" class="btn btn-danger">X</a>
                        </td>
                    </tr>

                    <?php
                    $total_quantity += $item["quantity"];
                    $total_price += ($item["price"]*$item["quantity"]);
                    
                }
                
                $finn=implode(",",$interm);
            }

            if (isset($_SESSION['cart_item']) && !empty($_SESSION['cart_item'])){
                ?>
                <tr>
                    <td colspan="2" align="right">Total:</td>
                    <td align="right"><strong><?= $finn ?></strong></td>
                    <td></td>
                    <td align="right"><strong>₹<?= number_format($total_price, 2); ?></strong></td>
                    <td></td>
                </tr>

            <?php }

                ?>
            </tbody>
        </table>
    </div>
   <?php         break;
   case 'confirm':
       
       $date = date("Y-m-d");
       $day = date("l");
       $ord= $_GET['code'];
      $ordarr = explode (",||,", $ord); 
       
       $tprice = $_GET['code1'];
       $totaldate = $date.$day;
  	   for($x=0;$x<count($ordarr);$x++)
  	   {
  	   $query = "INSERT INTO orderstable (useremail, orders, totalprice, date) VALUES ('$userem', '$ordarr[$x]', '$tprice', '$date')";
  	   $result = mysqli_query($con, $query);
  	   }
     if($result){
    // echo 'Success';
     unset($_SESSION['cart_item']);
    // echo "<h1>Order Placed Successfully</h1>";
    
     header('location:new.php');
     exit();
         
     }
     else{
     //echo 'failure'.$con->error;
     echo "<script>
alert('Something went wrong, please try again...');
</script>";
     }
    break;
            
    }
}


?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Lank's Shopping</title>
    <link rel="stylesheet" href="cartstyles.css">
     <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link href='https://css.gg/profile.css' rel='stylesheet'>
<style>
body {
  -ms-overflow-style: none; /* for Internet Explorer, Edge */
  scrollbar-width: none; /* for Firefox */
  overflow-y: scroll; 
}

body::-webkit-scrollbar {
  display: none; /* for Chrome, Safari, and Opera */
}

.header {
  padding: 2px;
  text-align: center;
  background: #1bac2c;
  color: white;
  font-size: 5px;
}
//profile
 .gg-profile,
.gg-profile::after,
.gg-profile::before {
 display: block;
 box-sizing: border-box;
 border: 2px solid;
 border-radius: 100px
}

.gg-profile {
 overflow: hidden;
 transform: scale(var(--ggs,1));
 width: 35px;
 height: 35px;
 position: relative
}

.gg-profile::after,
.gg-profile::before {
 content: "";
 position: absolute;
 top: 12px;
 left: 15px;
 width: 18px;
 height: 18px
}

.gg-profile::after {
 border-radius: 200px;
 top: 11px;
 left: 0px;
 width: 18px;
 height: 18px
} 

</style>
</head>
<body>
    <div class="header">
  <div align="left">
      <div class="row">
          <div class="column">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
          <div class="column">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
          <div class="column">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
        <div class="column">  
      &nbsp;&nbsp;&nbsp;&nbsp;<a href="buyorder.php">&nbsp;&nbsp;<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
  <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/>
</svg><br><p style="font-size:15px;">My Orders</p>
    </a>
</div>
<div class="column">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="column">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="column">
<a href="/lank/index.php">&nbsp;&nbsp;<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-house-door" viewBox="0 0 16 16">
  <path d="M8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4.5a.5.5 0 0 0 .5-.5v-4h2v4a.5.5 0 0 0 .5.5H14a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.354 1.146zM2.5 14V7.707l5.5-5.5 5.5 5.5V14H10v-4a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5v4H2.5z"/>
</svg><br><p style="font-size:15px;">&nbsp;Home</p></a>
</div>
<div class="column">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="column">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="column">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</div>
<div class="column">
    <a type="button" data-toggle="modal" data-target="#myModal">&nbsp;&nbsp;<svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-cart4" viewBox="0 0 16 16">
  <path d="M0 2.5A.5.5 0 0 1 .5 2H2a.5.5 0 0 1 .485.379L2.89 4H14.5a.5.5 0 0 1 .485.621l-1.5 6A.5.5 0 0 1 13 11H4a.5.5 0 0 1-.485-.379L1.61 3H.5a.5.5 0 0 1-.5-.5zM3.14 5l.5 2H5V5H3.14zM6 5v2h2V5H6zm3 0v2h2V5H9zm3 0v2h1.36l.5-2H12zm1.11 3H12v2h.61l.5-2zM11 8H9v2h2V8zM8 8H6v2h2V8zM5 8H3.89l.5 2H5V8zm0 5a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0zm9-1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0z"/>
</svg><br><p style="font-size:15px;">&nbsp;&nbsp;&nbsp;Cart</p></a>
</div>
</div>
</div>

  <h1><center> <h1>Lank's Shopping</h1> </center></h1>
  <p style="font-size:20px;">shop your favorite items here</p>
  
   <form align="right" name="form1" method="post" action="logout-user.php">
         
          <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Checkout
          <span class="glyphicon glyphicon-shopping-cart" style="color:white;" width="550px;"></span>
         <span class="badge"></span>
             <?php 
             if(isset($_SESSION['cart_item']))
             {
             $sizeofc = count($_SESSION['cart_item']);
             ?>
             <span class="badge">
             <?php echo "".$sizeofc ?>
             </span>
             <?php
             }
             ?>
          </button>&nbsp;&nbsp;
          <button type="button" class="btn btn-info btn-sm">
          <input name="submit2" type="submit" id="submit2" value="Logout" style="padding:right:10px;" class="btn btn-info">&nbsp;<span class="glyphicon glyphicon-off" style="color:white;" width="550px;"></span>&nbsp;&nbsp; 
        </button>
  <br>
  <br>
  <a class="btn btn-danger btn-lg" href="dress.php?action=empty">Remove all from cart &nbsp;<span class="glyphicon glyphicon-trash" style="color:white;" width="550px;"></span>&nbsp;&nbsp;</a> 
</form>
</div>
</div>
<header>
   
     
</header>

<div class="container py-5">
    <div class="d-flex justify-content-between mb-3">
    </div>
    <div class="row" style="display:none;">
        <?php
            $total_quantity = 0;
            $total_price = 0;
        ?>
        <table class="table">
            <tbody>
            <tr>
                <th class="text-left">Name</th>
                <th class="text-left">Code</th>
                <th class="text-right">Quantity</th>
                <th class="text-right">Item Price</th>
                <th class="text-right">Price</th>
                <th class="text-center">Remove</th>
            </tr>

            <?php
            if (isset($_SESSION['cart_item']) && !empty($_SESSION['cart_item'])){
                foreach ($_SESSION['cart_item'] as $item) {
                    $item_price = $item['quantity'] * $item['price'];
                    ?>
                    <tr>
                        <td class="text-left">
                            <img src="images/<?= $item['imagename']; ?>" alt="<?= $item['name'] ?>" class="img-fluid" width="100">
                            <?= $item['name'] ?>
                        </td>
                        <td class="text-left"><?= $item['name'] ?></td>
                        <td class="text-right"><?= $item['quantity'] ?></td>
                        <td class="text-right">$<?= number_format($item['price'], 2) ?></td>
                        <td class="text-right">$<?= number_format($item_price, 2) ?></td>
                        <td class="text-center">
                            <a href="dress.php?action=remove&code=<?= $item['code']; ?>" class="btn btn-danger">X</a>
                        </td>
                    </tr>

                    <?php
                    $total_quantity += $item["quantity"];
                    $total_price += ($item["price"]*$item["quantity"]);
                }
            }

            if (isset($_SESSION['cart_item']) && !empty($_SESSION['cart_item'])){
                ?>
                <tr>
                    <td colspan="2" align="right">Total:</td>
                    <td align="right"><strong><?= $total_quantity ?></strong></td>
                    <td></td>
                    <td align="right"><strong>₹<?= number_format($total_price, 2); ?></strong></td>
                    <td></td>
                </tr>

            <?php }

                ?>
            </tbody>
        </table>
    </div>
<br>
<center>
    <!-- first done this -->
    <div class="row">
        <div style="padding-left:200px;">
            <div class="d-flex">
                <div class="card-deck">
                    <?php
                    $query = "SELECT * FROM imagestable";
                    //$product = mysqli_query($con, $query);
                    $product = $resultindex;
                    if (!empty($product)) {
                        while ($row = mysqli_fetch_array($product)) { ?>
                            <form action="dress.php?action=add&pid=<?= $row['id']; ?>" method="post">
                                <div class="w3-card-4" style="width:95%">
                                   <center> <img width="100" height="100"
                                         src="images/<?= $row['imagename']; ?>"
                                         alt="<?= $row['name']; ?>"
                                         ></center>
                                    <div>
                                        <span><?= $row['name']; ?></span><br>
                                        <span>$<?= number_format($row['price'], 2); ?></span>
                                    </div>
                                    <div class="card-body d-flex justify-content-between">
                                        <input type="text" name="quantity" value="1" size="1">
                                        &nbsp;&nbsp;<input type="submit" value="Add to Cart" class="btn btn-success btn-sm">
                                    </div>
                                </div>
                            </form>
                        <?php }
                    } else {
                        echo "no products available";
                    }
                    ?>
                </div>
            </div>
           
        </div>
    </div>
    <br>
    
<?php
for ($page=1;$page<=$number_of_pages;$page++) {
  echo '<a href="/lank/dress.php?page=' . $page . '" class="btn btn-primary">' . $page . '</a> ';
}
?>
</center>

</div>
<div class="container">
<!--  <h2>Modal Example</h2>-->
  <!-- Trigger the modal with a button -->
  <!--<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">Open Modal</button>
-->
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
                <div class="row">
        <?php
             $total_quantity = 0;
            $total_price = 0;
            // $finn="";
            // $fb2="";
            // $namesofitems = array();
            // $interm= array();$sepp=":"
        ?>
        <table class="table">
            <tbody>
            <tr>
                <th class="text-left">Wallposter</th>
                <th class="text-left"></th>
                <th class="text-right">Quantity</th>
                <th class="text-right">Item Price</th>
                <th class="text-right">Price</th>
                <th class="text-center">Remove</th>
            </tr>

            <?php
            if (isset($_SESSION['cart_item']) && !empty($_SESSION['cart_item'])){?>
                
                <?php
                foreach ($_SESSION['cart_item'] as $item) {
                    $item_price = $item['quantity'] * $item['price'];
                    /*start*/
                    array_push($interm,"SellerEmail:".$item['selleremail'],"Category:".$item['category'],"Name:".$item['name'],"Quantity:".$item['quantity'],"price of individual item: ".$item['price'],"quantity_total_price: ".$item_price,"||");
                    array_push($namesofitems,$item['name'])
                    /*end*/
                    ?>
                    <br>
                    <tr>
                        <td class="text-left">
                            <img src="images/<?= $item['imagename']; ?>" alt="<?= $item['name'] ?>" class="img-fluid" width="100">
                            <?= $item['name'] ?>
                        </td>
                        <td class="text-left"></td>
                        <td class="text-right"><?= $item['quantity'] ?></td>
                        <td class="text-right">$<?= number_format($item['price'], 2) ?></td>
                        <td class="text-right">$<?= number_format($item_price, 2) ?></td>
                        <td class="text-center">
                            <a href="dress.php?action=remove&code=<?= $item['code']; ?>" class="btn btn-danger">X</a>
                        </td>
                    </tr>

                    <?php
                    $total_quantity += $item["quantity"];
                    $total_price += ($item["price"]*$item["quantity"]);
                    $tot += $total_price;
                }
                
                $finn=implode(",",$interm);
                $fb2 = substr($finn,0,-3);
                
            }

            if (isset($_SESSION['cart_item']) && !empty($_SESSION['cart_item'])){
                ?>
                <tr>
                    <td colspan="2" align="right">Total Price:</td>
                    <!--<td align="right"><strong><?= $fb2 ?></strong></td>
                    --><td></td>
                    <td align="right"><strong>$<?= number_format($total_price, 2); ?></strong></td>
                    <td></td>
                </tr>
<center><td class="text-right"><a class="btn btn-success" href="dress.php?action=confirm&code=<?= $fb2; ?>&code1=<?= $total_price; ?>">Confirm my order</td></a></center>
            <?php }

                ?>
                
            </tbody>
        </table>
    </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
  


</body>
</html>

