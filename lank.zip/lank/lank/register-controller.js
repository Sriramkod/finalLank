var con = require('./config');
module.exports.register=function(req,res){
    var today = new Date();
    
 name = req.query.name, 
 email = req.query.email, 
 password = req.query.password,
 created_at = today,
 updated_at = today

var sql = `INSERT INTO users (name,email,password,created_at,updated_at) VALUES 
              (?,?,?,?,?)`;
  con.query(sql,[name,email,password,created_at,updated_at], function (err, result) {
    if (err) throw err;
else{
    console.log("1 record inserted");
 res.json({
            status:true,
            data:result,
            message:'user registered sucessfully'
        })
}  
});
  
}