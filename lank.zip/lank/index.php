<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;700&display=swap" rel="stylesheet" />

  <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon" />


  <!-- Carousel -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/css/glide.core.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/css/glide.theme.min.css
">
  <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

  <!-- Custom StyleSheet -->
  <link rel="stylesheet" href="indexstyles.css" />

  <title>Lank's Shopping</title>
  <style>
       .header {
  padding: 2px;
  text-align: center;
  background: #1bac2c;
  color: white;
  font-size: 5px;
      }
body {
  overflow: hidden; /* Hide scrollbars */
}
  </style>
</head>

<body>

  <!-- Header -->
  <header id="header" class="header">
    <div class="navigation">
      <div class="container">
        <nav class="nav">
          <div class="nav__hamburger">
            <svg>
              <use xlink:href="./images/sprite.svg#icon-menu"></use>
            </svg>
          </div>

          <div class="nav__logo">
            <a href="/" class="scroll-link">
              <div style="color:white">Lank's Shopping</div>
            </a>
          </div>

          <div class="nav__menu">
            <div class="menu__top">
              <span class="nav__category">Lank's Shopping</span>
              <a href="#" class="close__toggle">
                <svg>
                  <use xlink:href="./images/sprite.svg#icon-cross"></use>
                </svg>
              </a>
            </div>
            <ul class="nav__list">
              <li class="nav__item">
              <div>  <a href="sellerlogin.php" style="color:white;font-size:15px;" >Sell an item</a></div>
              </li>
               <li class="nav__item">
              <div>  <a href="home.php"  style="color:white;font-size:15px;">Shop now</a></div>
              </li>
            </ul>
          </div>
 <a href="login.php" class="icon__item">
             <h1 style="color:white;font-size:17px;" >Login now</h1>
            </a>
          <div class="nav__icons">

           
          </div>
        </nav>
      </div>
    </div>

    <!-- Hero -->
    <div class="hero">
      <div class="glide" id="glide_1">
        <div class="glide__track" data-glide-el="track">
          <ul class="glide__slides">
            <li class="glide__slide">
              <div class="hero__center">
                <div class="hero__left">
                  <span style="color:black; font-size:20px;">LANK'S SHOPPING</span>
                  <h1 style="color:blue; font-size:25px;">Dresses you may like, having awesome quality</h1>
                  
                  <a href="login.php"><button class="hero__btn">SHOP NOW</button></a>
                </div>
                <div class="hero__right">
                  <div class="hero__img-container">
                    <img class="banner_01" src="./images/sim1.jpeg" alt="banner2" />
                  </div>
                </div>
              </div>
            </li>
            <li class="glide__slide">
              <div class="hero__center">
                <div class="hero__left">
                  <span style="color:black; font-size:20px;">LANK'S SHOPPING</span>
                  <h1 style="color:blue; font-size:25px;">Dresses you may like, these are trending now...</h1>
                  <a href="login.php"><button class="hero__btn">SHOP NOW</button></a>
                </div>
                <div class="hero__right">
                  <img class="banner_02" src="./images/sim2.jpeg" alt="banner2" />
                </div>
              </div>
              
            </li>
                        <li class="glide__slide">
              <div class="hero__center">
                <div class="hero__left">
                  <span style="color:black; font-size:25px;">LANK'S SHOPPING</span>
                  <h1 style="color:blue; font-size:25px;">BOAT, Brand new electronic gadgets</h1>
                  <p></p>
                  <a href="login.php"><button class="hero__btn">SHOP NOW</button></a>
                </div>
                <div class="hero__right">
                  <img class="banner_02" src="./images/indeximages/headphone3.jpeg" alt="banner2" />
                </div>
              </div>
              
            </li>
                   <li class="glide__slide">
              <div class="hero__center">
                <div class="hero__left">
                  <span style="color:black; font-size:25px;">LANK'S SHOPPING</span>
                  <h1 style="color:blue; font-size:25px;">BOAT, Brand new electronic gadgets</h1>
                  <p></p>
                  <a href="login.php"><button class="hero__btn">SHOP NOW</button></a>
                </div>
                <div class="hero__right">
                  <img class="banner_02" src="./images/indeximages/headphone1.jpeg" alt="banner2" />
                </div>
              </div>
              
            </li>
             <li class="glide__slide">
              <div class="hero__center">
                <div class="hero__left">
                  <span style="color:black; font-size:25px;">LANK'S SHOPPING</span>
                  <h1 style="color:blue; font-size:25px;">We sell branded phones</h1>
                  <p></p>
                  <a href="login.php"><button class="hero__btn">SHOP NOW</button></a>
                </div>
                <div class="hero__right">
                  <img class="banner_02" src="./images/indeximages/iphone5.jpeg" alt="banner2" />
                </div>
              </div>
              
            </li>
             <li class="glide__slide">
              <div class="hero__center">
                <div class="hero__left">
                  <span style="color:black; font-size:25px;">LANK'S SHOPPING</span>
                  <h1 style="color:blue; font-size:25px;">We sell branded phones</h1>
                  <p></p>
                  <a href="login.php"><button class="hero__btn">SHOP NOW</button></a>
                </div>
                <div class="hero__right">
                  <img class="banner_02" src="./images/indeximages/iphone4.jpeg" alt="banner2" />
                </div>
              </div>
              
            </li>
          </ul>
        </div>
        <div class="glide__bullets" data-glide-el="controls[nav]">
          <button class="glide__bullet" data-glide-dir="=0"></button>
          <button class="glide__bullet" data-glide-dir="=1"></button>
          <button class="glide__bullet" data-glide-dir="=2"></button>
          <button class="glide__bullet" data-glide-dir="=3"></button>
          <button class="glide__bullet" data-glide-dir="=4"></button>
          <button class="glide__bullet" data-glide-dir="=5"></button>
        </div>

        <div class="glide__arrows" data-glide-el="controls">
          <button class="glide__arrow glide__arrow--left" data-glide-dir="<">
            <svg>
              <use xlink:href="./images/sprite.svg#icon-arrow-left2"></use>
            </svg>
          </button>
          <button class="glide__arrow glide__arrow--right" data-glide-dir=">">
            <svg>
              <use xlink:href="./images/sprite.svg#icon-arrow-right2"></use>
            </svg>
          </button>
        </div>
      </div>
    </div>
  </header>
  <!-- End Header -->

  <!-- Main -->
  <main id="main">
    <div class="container">
      <!-- Collection -->
     </div>
     

     
  
   

  
  </main>

  <!-- End Main -->

  

  <!-- PopUp -->
  <div class="popup hide__popup">
    <div class="popup__content">
      <div class="popup__close">
        <svg>
          <use xlink:href="./images/sprite.svg#icon-cross"></use>
        </svg>
      </div>
      <div class="popup__left">
        <div class="popup-img__container">
          <img class="popup__img" src="./projectimages/project-bag.png" alt="popup">
          
          
        </div>
      </div>
      <div class="popup__right">
        <div class="right__content">
          <h1>Get Discount <span>10%</span> Off</h1>
          <p>Sign up to now and save 10% on your next order!
          </p>
          <form action="#">
            
            <a href="signup-user.php">Signup now</a>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- Go To -->

  <a href="#header" class="goto-top scroll-link">
    <svg>
      <use xlink:href="./images/sprite.svg#icon-arrow-up"></use>
    </svg>
  </a>


  <!-- Glide Carousel Script -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.4.1/glide.min.js"></script>
  <!-- Animate On Scroll -->
  <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

  <!-- Custom JavaScript -->
  <script src="./js/products.js"></script>
  <script src="./js/index.js"></script>
  <script src="./js/slider.js"></script>

</body>

</html>