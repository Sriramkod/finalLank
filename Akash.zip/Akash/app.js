const express = require('express');
const bodyParser =  require('body-parser');
const mysql = require('mysql');

const app = express();
const port = process.env.PORT || 5000
app.use(bodyParser.urlencoded({extended: false}))

app.use(bodyParser.json())

// MSQL
const pool  = mysql.createPool({
    connectionLimit: 10,
    host: "localhost",
    user: "root",
    password: "",
    database: "node_test"
});

//get all Details

app.get("/beers", (req,res) => {
    pool.getConnection((err, connection) => {
                if(err) throw err
                console.log(`connected as id ${connection.threadId}`)
                
                //query(sqlString, callBackFunction)
                connection.query("SELECT * FROM BEERS", (err, rows) => {
                        connection.release() // return connection back to pool

                        if(!err){
                            res.send(rows)
                        }
                        else{
                            console.log(err);
                        }
                })
    })
});

//get specific details.......based on id;
app.get("/beers/:id", (req,res) => {
    pool.getConnection((err, connection) => {
                if(err) throw err
                console.log(`connected as id ${connection.threadId}`)
                
                //query(sqlString, callBackFunction)
                connection.query("SELECT * FROM BEERS WHERE id = ?",[req.params.id], (err, rows) => {
                        connection.release() // return connection back to pool

                        if(!err){
                            res.send(rows)
                        }
                        else{
                            console.log(err);
                        }
                })
    })
});

//Delete a record
app.delete("/beers/:id", (req,res) => {
    pool.getConnection((err, connection) => {
                if(err) throw err
                console.log(`connected as id ${connection.threadId}`)
                
                //query(sqlString, callBackFunction)
                connection.query("DELETE FROM BEERS WHERE id = ?",[req.params.id], (err, rows) => {
                        connection.release() // return connection back to pool

                        if(!err){
                            res.send(`Records with the recors id ${req.params.id} has been removed`);
                        }
                        else{
                            console.log(err);
                        }
                })
    })
});

//add a new record
app.post("/beers", (req,res) => {
    pool.getConnection((err, connection) => {
                if(err) throw err
                console.log(`connected as id ${connection.threadId}`)
                const params = req.body

                //query(sqlString, callBackFunction)
                connection.query("INSERT INTO BEERS SET ?", params, (err, rows) => {
                        connection.release() // return connection back to pool

                        if(!err){
                            res.send(`Records with the id ${params.id} has been added successfully..`);
                        }
                        else{
                            console.log(err);
                        }
                })
                console.log(req.body);
    })
});

//Update a record
app.put("/beers", (req,res) => {
    pool.getConnection((err, connection) => {
                if(err) throw err
                console.log(`connected as id ${connection.threadId}`)
                const {id, name, tagline, description, image} = req.body

                //query(sqlString, callBackFunction)
                connection.query("UPDATE BEERS SET name = ? where id = ?", [name, id], (err, rows) => {
                        connection.release() // return connection back to pool

                        if(!err){
                            res.send(`Records with the id ${id} has updated successfully..`);
                        }
                        else{
                            console.log(err);
                        }
                })
                console.log(req.body);
    })
});
//Listen on environbment port 5000
app.listen(port, ()=> console.log(`Listeninig on port ${port}`))